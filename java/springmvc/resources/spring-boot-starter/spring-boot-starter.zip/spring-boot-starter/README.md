## [首次使用指引](https://github.com/jgnan/edu/blob/master/java/springmvc/resources/spring-boot-prototype/docs/cn/setup.md)
* [安装Maven](#install-maven)
  * [Windows](#install-maven-win)
  * [Mac OSX](#install-maven-osx)
* [初次下载依赖包](#download-repositories)

