class Image < ActiveRecord::Base
end
